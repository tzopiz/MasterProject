#!/bin/bash
cd "$(dirname "$0")"

echo "==============================================="
echo "       TMJ ANNOTATION TOOL SETUP"
echo "==============================================="

# 1. Setup Python Environment
if [ ! -d "venv" ]; then
    echo "🔧 Creating virtual environment..."
    # Try python3 first, then python
    if command -v python3 &>/dev/null; then
        python3 -m venv venv
    else
        python -m venv venv
    fi
fi

echo "🔌 Activating environment..."
source venv/bin/activate

echo "📦 Checking dependencies..."
pip install -r requirements.txt -q

echo ""
echo "==============================================="
echo "       READY TO ANNOTATE"
echo "==============================================="
echo ""

# 2. Get Input Directory
while true; do
    echo "📂 Drag and drop the folder containing ALL studies here, then press Enter:"
    read -r INPUT_DIR
    # Remove quotes if present (happens with drag & drop)
    INPUT_DIR="${INPUT_DIR%\"}"
    INPUT_DIR="${INPUT_DIR#\"}"
    # Trim whitespace
    INPUT_DIR="$(echo "$INPUT_DIR" | xargs)"
    
    if [ -d "$INPUT_DIR" ]; then
        break
    else
        echo "❌ Invalid directory. Please try again."
    fi
done

# 3. Get Output Directory
echo ""
echo "📂 Drag and drop folder for saving JSONs (or press Enter to save inside input folder):"
read -r OUTPUT_DIR
# Remove quotes
OUTPUT_DIR="${OUTPUT_DIR%\"}"
OUTPUT_DIR="${OUTPUT_DIR#\"}"
OUTPUT_DIR="$(echo "$OUTPUT_DIR" | xargs)"

if [ -z "$OUTPUT_DIR" ]; then
    OUTPUT_DIR="$INPUT_DIR/annotations"
    mkdir -p "$OUTPUT_DIR"
    echo "Using default output: $OUTPUT_DIR"
fi

# 4. Iterate through folders
echo ""
echo "🚀 Starting annotation session..."
echo "Press 'Q' in the window to save and go to next."
echo "Press 'Esc' to skip."
echo ""

count=0
for study_path in "$INPUT_DIR"/*; do
    if [ -d "$study_path" ]; then
        study_name=$(basename "$study_path")
        
        if [ -f "$OUTPUT_DIR/${study_name}_rois.json" ]; then
            echo "⏩ Skipping $study_name (already done)"
            continue
        fi
        
        echo "----------------------------------------"
        echo "Processing: $study_name"
        
        # Check for DICOMs (rudimentary check)
        # Just check if directory is not empty of files
        if [ -z "$(ls -A "$study_path")" ]; then
             echo "⚠️ Empty folder, skipping..."
             continue
        fi
        
        python roi_annotation_tool.py             --scan_id "$study_name"             --dicom_dir "$study_path"             --output_dir "$OUTPUT_DIR"
            
        ((count++))
    fi
done

echo ""
echo "🎉 Done! Processed $count studies."
echo "Results saved in: $OUTPUT_DIR"
echo "Press any key to exit..."
read -n 1
