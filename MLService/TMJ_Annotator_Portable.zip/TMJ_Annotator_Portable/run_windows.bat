@echo off
setlocal EnableDelayedExpansion

echo ===============================================
echo        TMJ ANNOTATION TOOL SETUP
echo ===============================================

REM 1. Setup Python Environment
if not exist "venv" (
    echo 🔧 Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo ❌ Error: Python not found or failed to create venv.
        echo Please install Python from https://www.python.org/downloads/
        pause
        exit /b
    )
)

echo 🔌 Activating environment...
call venv\Scripts\activate.bat

echo 📦 Checking dependencies...
pip install -r requirements.txt -q

echo.
echo ===============================================
echo        READY TO ANNOTATE
echo ===============================================
echo.

REM 2. Get Input Directory
:ask_input
echo 📂 Drag and drop the folder containing ALL studies here, then press Enter:
set /p INPUT_DIR=
REM Remove quotes
set INPUT_DIR=%INPUT_DIR:"=%

if not exist "%INPUT_DIR%" (
    echo ❌ Invalid directory. Please try again.
    goto ask_input
)

REM 3. Get Output Directory
echo.
echo 📂 Drag and drop folder for saving JSONs (or press Enter to save inside input folder):
set /p OUTPUT_DIR=
if "%OUTPUT_DIR%"=="" (
    set "OUTPUT_DIR=%INPUT_DIR%\annotations"
) else (
    set OUTPUT_DIR=%OUTPUT_DIR:"=%
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"
echo Using output: "%OUTPUT_DIR%"

REM 4. Iterate through folders
echo.
echo 🚀 Starting annotation session...
echo Press 'Q' in the window to save and go to next.
echo Press 'Esc' to skip.
echo.

set count=0
for /d %%D in ("%INPUT_DIR%\*") do (
    set "study_path=%%D"
    set "study_name=%%~nxD"
    
    if exist "%OUTPUT_DIR%\!study_name!_rois.json" (
        echo ⏩ Skipping !study_name! (already done)
    ) else (
        echo ----------------------------------------
        echo Processing: !study_name!
        
        python roi_annotation_tool.py --scan_id "!study_name!" --dicom_dir "!study_path!" --output_dir "%OUTPUT_DIR%"
        
        set /a count+=1
    )
)

echo.
echo 🎉 Done! Processed !count! studies.
echo Results saved in: "%OUTPUT_DIR%"
echo Press any key to exit...
pause >nul
